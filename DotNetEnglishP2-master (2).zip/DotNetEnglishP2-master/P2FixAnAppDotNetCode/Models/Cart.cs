﻿using System.Collections.Generic;
using System.Linq;

namespace P2FixAnAppDotNetCode.Models
{
    /// <summary>
    /// The Cart class
    /// </summary>
    public class Cart : ICart
    {
        private int lineId = 1;
        private List<CartLine> _lines = new List<CartLine>();
        /// <summary>
        /// Read-only property for dispaly only
        /// </summary>
        public IEnumerable<CartLine> Lines => GetCartLineList();

        /// <summary>
        /// Return the actual cartline list
        /// </summary>
        /// <returns></returns>
        private List<CartLine> GetCartLineList()
        {
            return new List<CartLine>(_lines);
        }

        /// <summary>
        /// Adds a product in the cart or increment its quantity in the cart if already added
        /// </summary>//
        public void AddItem(Product product, int quantity)
        {
            foreach (CartLine line in _lines)
            {
                if (product.Id == line.Product.Id)
                {
                    line.Quantity += quantity;
                    return;
                }
            }
            CartLine newLine = new CartLine();
            newLine.OrderLineId = lineId;
            lineId++;
            newLine.Product = product;
            newLine.Quantity = quantity;
            _lines.Add(newLine);
        }

        /// <summary>
        /// Removes a product form the cart
        /// </summary>
        public void RemoveLine(Product product) =>
            GetCartLineList().RemoveAll(l => l.Product.Id == product.Id);

        /// <summary>
        /// Get total value of a cart
        /// </summary>
        public double GetTotalValue()
        {
            double total = 0;
            foreach (CartLine line in _lines)
            {
                total += line.Quantity * line.Product.Price;
            }
            return total;
        }

        /// <summary>
        /// Get average value of a cart
        /// </summary>
        public double GetAverageValue()
        {
            int items = 0;
            foreach (CartLine line in _lines)
            {
                items += line.Quantity;
            }
            if (items == 0)
            {
                return 0.0;
            }
            return GetTotalValue() / items;
        }

        /// <summary>
        /// Looks after a given product in the cart and returns if it finds it
        /// </summary>
        public Product FindProductInCartLines(int productId)
        {
            foreach (CartLine line in _lines)
            {
                if (line.Product.Id == productId)
                {
                    return line.Product;
                }
            }
            return null;
        }

        /// <summary>
        /// Get a specifid cartline by its index
        /// </summary>
        public CartLine GetCartLineByIndex(int index)
        {
            return Lines.ToArray()[index];
        }

        /// <summary>
        /// Clears a the cart of all added products
        /// </summary>
        public void Clear()
        {
            List<CartLine> cartLines = GetCartLineList();
            cartLines.Clear();
        }
    }

    public class CartLine
    {
        public int OrderLineId { get; set; }
        public Product Product { get; set; }
        public int Quantity { get; set; }
    }
}
